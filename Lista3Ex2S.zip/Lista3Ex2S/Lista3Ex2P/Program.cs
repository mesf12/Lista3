﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex2P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;

            Console.WriteLine("Digite o primeiro valor: ");
            a = int.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("Digite o segundo valor: ");
                b = int.Parse(Console.ReadLine());

            }
            while (b <= a);

        }
    }
}
