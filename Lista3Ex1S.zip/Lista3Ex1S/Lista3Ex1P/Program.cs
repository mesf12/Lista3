﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex1P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;

            Console.WriteLine("Digite o valor: ");
            a = int.Parse(Console.ReadLine());

            if( a > 0)
            {
                Console.WriteLine("Positivo");
            }
            else
            {
                if ( a < 0)
                {
                    Console.Write("Negativo");
                }
                else
                {
                    Console.Write("Zero");
                }

            }
        }
    }
}
